import numpy as np

base = np.array([i for i in range(12)])

a_1_12 = base.reshape((1,12))
a_2_6 = base.reshape((2,6))
a_3_4 = base.reshape((3,4))
a_4_3 = base.reshape((4,3))
a_6_2 = base.reshape((6,2))
a_12_1 = base.reshape((12,1))




