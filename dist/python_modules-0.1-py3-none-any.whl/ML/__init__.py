import os,sys
sys.path.append(os.path.dirname(__file__))

from neural import neuralNetwork,Regression,Classification
from algorithm import *
