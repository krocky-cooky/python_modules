import os,sys
sys.path.append(os.path.dirname(__file__))

from pdf_python import *

